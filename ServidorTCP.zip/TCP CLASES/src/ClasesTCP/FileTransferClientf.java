package ClasesTCP;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;


public class FileTransferClientf { 
    
    public static void main(String[] args) throws Exception{
        
        //Initialize socket
    	//String ip = Inet4Address.getByName("localhost").getCanonicalHostName();
        Socket socket = new Socket("localhost", 5000);
        byte[] contents = new byte[10000];
        
        //Initialize the FileOutputStream to the output file's full path.
        String home = System.getProperty("user.home");
        
        File f = new File(home + File.separator + "Desktop" + File.separator + "ClienteTCP" + File.separator + "2.wmv");
        String ruta=f.getAbsolutePath();
        FileOutputStream fos = new FileOutputStream(f);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        InputStream is = socket.getInputStream();
        
        //No of bytes read in one read() call
        int bytesRead = 0; 
        
        while((bytesRead=is.read(contents))!=-1)
            bos.write(contents, 0, bytesRead); 
        
        bos.flush(); 
        socket.close(); 
        
        System.out.println("Se ha recibido correctamente!");
        Runtime r=Runtime.getRuntime();
		try {
			
			r.exec(new String[]{"open","-a","VLC",ruta	});


		} catch (IOException ex) {
			System.out.println("Ha dejado de funcionar");
			ex.printStackTrace();
		}
    }
}